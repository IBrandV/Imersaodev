var valorDolar=prompt("Diga o valor em dolar")
valorReal=(parseFloat(valorDolar)*5.5).toFixed(2)
alert("R$"+valorReal)